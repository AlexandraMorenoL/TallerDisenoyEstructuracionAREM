package co.edu.escuelaing.httpserver;

import java.net.*;
import java.io.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Servidor UDP que responde la hora actual a los cliente
 * - Escucha en el puerto 35004.
 * - Al recibir un datagrama (ej. con el mensaje "TIME"), imprime el contenido.
 * - Responde al cliente con la hora actual en formato HH:mm:ss.
 * - Funciona en un bucle infinito, atendiendo múltiples solicitudes.
 *
 * Autor: Alexandra Moreno Latorre
 */

public class TimeServerUDP {
    public static void main(String[] args) {
        int port = 35004;
        byte[] buffer = new byte[256];

        try (DatagramSocket socket = new DatagramSocket(port)) {
            System.out.println("Servidor UDP de hora escuchando en puerto " + port);

            while (true) {
                // Esperar datagrama del cliente
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                socket.receive(request);

                String received = new String(request.getData(), 0, request.getLength());
                System.out.println("Recibido: " + received);

                // Generar hora actual
                String currentTime = LocalTime.now()
                        .format(DateTimeFormatter.ofPattern("HH:mm:ss"));

                byte[] responseData = currentTime.getBytes();

                // Responder al cliente con la hora actual
                DatagramPacket response = new DatagramPacket(
                        responseData, responseData.length,
                        request.getAddress(), request.getPort());

                socket.send(response);
                System.out.println("Enviado: " + currentTime);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
