package co.edu.escuelaing.httpserver;

import java.net.*;
import java.io.*;

/**
 * Cliente UDP que solicita cada 5 segundos la hora a un servidor de tiempo.
 * - Si recibe la hora, la muestra y la guarda como última recibida.
 * - Si no hay respuesta (timeout), muestra la última hora conocida.
 *
 * Autor: Alexandra Moreno Latorre
 */

public class TimeClientUDP {
    public static void main(String[] args) {
        String serverHost = "127.0.0.1";
        int serverPort = 35004;
        String lastTime = "Sin hora recibida aún";

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(2000); // esperar máx 2 segundos cada intento
            InetAddress address = InetAddress.getByName(serverHost);

            while (true) {
                try {
                    String msg = "TIME";
                    byte[] sendData = msg.getBytes();
                    DatagramPacket request = new DatagramPacket(sendData, sendData.length, address, serverPort);
                    socket.send(request);

                    byte[] buffer = new byte[256];
                    DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                    socket.receive(response);

                    String serverTime = new String(response.getData(), 0, response.getLength());
                    lastTime = serverTime;
                    System.out.println("Hora recibida del servidor: " + serverTime);

                } catch (SocketTimeoutException e) {
                    System.out.println("No se recibió hora. Manteniendo: " + lastTime);
                }

                // Esperar 5 segundos antes de la siguiente petición
                Thread.sleep(5000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
