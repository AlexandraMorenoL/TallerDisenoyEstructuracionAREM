package co.edu.escuelaing.httpserver;

import java.net.*;
import java.io.*;

/**
 * Cliente TCP para un servidor "echo".
 
 * @author Alexandra Moreno Latorre
 */
public class EchoClient {

    /**
     * Punto de entrada del cliente.
     */
    public static void main(String[] args) throws IOException {
        String host = (args != null && args.length >= 1) ? args[0] : "127.0.0.1";
        int port = 35001;
        if (args != null && args.length >= 2) {
            try {
                port = Integer.parseInt(args[1]);
            } catch (NumberFormatException nfe) {
                System.err.println("Puerto inválido en argumentos, usando 35001.");
                port = 35001;
            }
        }

        try (Socket echoSocket = new Socket(host, port);
             PrintWriter out = new PrintWriter(echoSocket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Conectado a " + host + ":" + port);
            System.out.println("Escribe líneas para enviarlas al servidor (Ctrl+D o Ctrl+C para salir).");

            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput);
                String serverResponse = in.readLine();
                if (serverResponse == null) {
                    System.out.println("El servidor cerró la conexión.");
                    break;
                }

                System.out.println("echo: " + serverResponse);
            }

        } catch (UnknownHostException e) {
            System.err.println("No se conoce el host: " + host + " (" + e.getMessage() + ")");
            System.exit(1);
        } catch (ConnectException e) {
            System.err.println("No se pudo conectar a " + host + ":" + port + " - " + e.getMessage());
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Error de E/S: " + e.getMessage());
            System.exit(1);
        }
    }
}
