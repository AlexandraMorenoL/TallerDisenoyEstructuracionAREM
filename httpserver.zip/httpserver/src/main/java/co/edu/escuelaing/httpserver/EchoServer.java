package co.edu.escuelaing.httpserver;

import java.io.*;
import java.net.*;

/**
 * Servidor TCP simple que acepta una conexión entrante en el puerto 35001.
 *
 * Comportamiento:
 * - Acepta un cliente (bloqueante) y lee líneas de texto.
 * - Si la línea es un número válido, responde con su cuadrado.
 * - Si no es un número, responde pidiendo un número válido.
 * - Cierra la conexión cuando el cliente cierra la entrada.
 *
 * Autor: Alexandra Moreno Latorre
 */
public class EchoServer {

    /**
     * Punto de entrada del servidor.
     * Escucha en el puerto 35001, acepta una conexión y procesa líneas hasta EOF.
     */
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(35001); 
            System.out.println("Servidor escuchando en el puerto 35001...");
        } catch (IOException e) {
            System.err.println("No se pudo abrir el puerto: 35001.");
            System.exit(1);
        }

        Socket clientSocket = null;
        try {
            clientSocket = serverSocket.accept();
            System.out.println("Cliente conectado...");
        } catch (IOException e) {
            System.err.println("Error al aceptar conexión.");
            System.exit(1);
        }

        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            System.out.println("Recibido: " + inputLine);

            try {
                double num = Double.parseDouble(inputLine);
                double cuadrado = num * num;
                out.println("El cuadrado es: " + cuadrado);
            } catch (NumberFormatException e) {
                out.println("Por favor ingresa un número válido.");
            }
        }

        out.close();
        in.close();
        clientSocket.close();
        serverSocket.close();
    }
}
