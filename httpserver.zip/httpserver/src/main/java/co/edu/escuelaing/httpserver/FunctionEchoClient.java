package co.edu.escuelaing.httpserver;

import java.io.*;
import java.net.*;

/**
 * 
 * Cliente para probar el FunctionServer en el puerto 35002.
 * Permite enviar números y comandos "fun:sin", "fun:cos", "fun:tan".
 * Autor: Alexandra Moreno Latorre
 */
public class FunctionEchoClient {

    public static void main(String[] args) throws IOException {
        Socket socket = null;
        PrintWriter out = null;
        BufferedReader in = null;

        try {
            socket = new Socket("127.0.0.1", 35002); // Puerto 35002
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("Conectado al FunctionServer en el puerto 35002");
        } catch (UnknownHostException e) {
            System.err.println("Host desconocido.");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("No se pudo establecer conexión con el servidor.");
            System.exit(1);
        }

        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        String userInput;

        System.out.println("👉 Escribe un número o cambia la función con fun:sin | fun:cos | fun:tan");
        while ((userInput = stdIn.readLine()) != null) {
            out.println(userInput);  
            System.out.println("📩 Respuesta del servidor: " + in.readLine());
        }

        out.close();
        in.close();
        stdIn.close();
        socket.close();
    }
}
