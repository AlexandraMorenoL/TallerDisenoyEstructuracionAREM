package co.edu.escuelaing.httpserver;

import java.io.*;
import java.net.*;
import java.util.function.DoubleUnaryOperator;

/**
 * Servidor TCP que aplica funciones matemáticas (sin, cos, tan) a valores recibidos.
 *
 * Comportamiento:
 * - Escucha en el puerto 35002 y atiende a un cliente.
 * - Recibe comandos de texto:
 *      • "fun:sin", "fun:cos", "fun:tan" → cambia la función matemática activa.
 *      • número → aplica la función actual al número y devuelve el resultado.
 * - Por defecto la función inicial es coseno.
 * - Si la entrada no es válida, responde con un mensaje de error.
 *
 * Autor: Alexandra Moreno Latorre
 */

public class FunctionServer {
    // Estado de la función actual (empieza en coseno)
    private static DoubleUnaryOperator currentFunction = Math::cos;

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(35002);
            System.out.println("FunctionServer escuchando en el puerto 35002...");
        } catch (IOException e) {
            System.err.println("No se pudo abrir el puerto: 35002.");
            System.exit(1);
        }

        Socket clientSocket = null;
        try {
            clientSocket = serverSocket.accept();
            System.out.println("Cliente conectado!");
        } catch (IOException e) {
            System.err.println("Fallo en la conexión.");
            System.exit(1);
        }

        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            System.out.println("Mensaje recibido: " + inputLine);

            if (inputLine.startsWith("fun:")) {
                // Cambiar función
                String func = inputLine.substring(4).trim();
                switch (func) {
                    case "sin":
                        currentFunction = Math::sin;
                        out.println("Función cambiada a seno");
                        break;
                    case "cos":
                        currentFunction = Math::cos;
                        out.println("Función cambiada a coseno");
                        break;
                    case "tan":
                        currentFunction = Math::tan;
                        out.println("Función cambiada a tangente");
                        break;
                    default:
                        out.println("Función no reconocida: " + func);
                }
            } else {
                try {
                    double value = Double.parseDouble(inputLine);
                    double result = currentFunction.applyAsDouble(value);
                    out.println(result);
                } catch (NumberFormatException e) {
                    out.println("Entrada inválida. Use un número o fun:<sin|cos|tan>");
                }
            }
        }

        out.close();
        in.close();
        clientSocket.close();
        serverSocket.close();
    }
}
