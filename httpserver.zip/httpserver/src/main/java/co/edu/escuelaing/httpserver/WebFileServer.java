package co.edu.escuelaing.httpserver;

import java.io.*;
import java.net.*;
import java.nio.file.*;

/**
 * Servidor web simple que entrega archivos estáticos desde la carpeta
 *
 * - Escucha en el puerto 35003. - Al recibir una petición HTTP, interpreta la
 * ruta solicitada. - Si la ruta es "/", devuelve "index.html". - Si el archivo
 * existe, responde con su contenido. - Si no existe, responde con un error 404
 * y un mensaje HTML simple.
 *
 * Autor: Alexandra Moreno Latorre
 */
public class WebFileServer {

    public static void main(String[] args) throws IOException {
        int port = 35003;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Servidor escuchando en puerto " + port);

        while (true) {
            try (Socket clientSocket = serverSocket.accept()) {
                System.out.println("Nueva conexión...");

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream()));
                OutputStream out = clientSocket.getOutputStream();

                // Leer primera línea del request (ej: "GET /index.html HTTP/1.1")
                String inputLine = in.readLine();
                if (inputLine == null) {
                    continue;
                }

                System.out.println("Petición: " + inputLine);
                String[] requestParts = inputLine.split(" ");
                String path = requestParts[1];

                if (path.equals("/")) {
                    path = "/index.html";
                }

                File file = new File("src/main/resources/public" + path);
                if (file.exists()) {
                    String contentType = guessContentType(file.getName());
                    byte[] fileBytes = Files.readAllBytes(file.toPath());

                    String header = "HTTP/1.1 200 OK\r\n"
                            + "Content-Type: " + contentType + "\r\n"
                            + "Content-Length: " + fileBytes.length + "\r\n"
                            + "\r\n";
                    out.write(header.getBytes());
                    out.write(fileBytes);
                } else {
                    String errorMsg = "HTTP/1.1 404 Not Found\r\n\r\n"
                            + "<h1>404 Archivo no encontrado</h1>";
                    out.write(errorMsg.getBytes());
                }
                out.flush();
            }
        }
    }

    private static String guessContentType(String fileName) {
        if (fileName.endsWith(".html")) {
            return "text/html";
        }
        if (fileName.endsWith(".css")) {
            return "text/css";
        }
        if (fileName.endsWith(".js")) {
            return "application/javascript";
        }
        if (fileName.endsWith(".png")) {
            return "image/png";
        }
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        return "application/octet-stream";
    }
}
